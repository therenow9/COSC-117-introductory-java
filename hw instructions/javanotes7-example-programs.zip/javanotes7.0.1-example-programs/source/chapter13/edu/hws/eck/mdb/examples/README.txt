
The files in this "examples" directory are used in the applet
version of the Mandelbrot Viewer program , which is defined in
the file MandelbrotApplet.java.  They are NOT needed by any
other part of the program.  

Note that these are "Params" files that can also be loaded by 
hand into the stand-alone application version of the program
using its Open Params command.

