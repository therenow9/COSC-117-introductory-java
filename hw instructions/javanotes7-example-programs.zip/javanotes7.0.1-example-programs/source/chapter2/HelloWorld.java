/** A program to display the message
 *  "Hello World!" on standard output.
 */
public class HelloWorld {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }

}   // end of class HelloWorld
